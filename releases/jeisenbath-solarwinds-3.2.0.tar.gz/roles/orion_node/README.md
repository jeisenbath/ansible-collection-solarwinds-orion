orion_node
=========

Adds an node to be monitored in Solarwinds.

Requirements
------------

jeisenbath.solarwinds collection

Role Variables
--------------

defaults/main.yml
```yaml
orion_node_solarwinds_server: "{{ solarwinds_server }}"
orion_node_solarwinds_username: "{{ solarwinds_username }}"
orion_node_solarwinds_password: "{{ solarwinds_password }}"
orion_node_caption_name: "{{ ansible_facts.nodename }}"
orion_node_ip_address: "{{ ansible_facts.default_ipv4.address }}"
orion_node_polling_method: ICMP
orion_node_snmp_pollers:
  - name: N.Cpu.SNMP.HrProcessorLoad
    enabled: true
  - name: N.Memory.SNMP.NetSnmpReal
    enabled: true
orion_node_discover_interfaces: false
orion_node_ncm: false
```

Variables required depending on the values of defaults
```yaml
# required when orion_node_polling method is SNMP, set which version of SNMP (choices: 2, 3)
orion_node_snmp_version:
# required when SNMP version is 2
orion_node_ro_community_string:
# required when SNMP version is 3
orion_node_snmpv3_credential_set:
orion_node_snmpv3_username:
orion_node_snmpv3_auth_key:
orion_node_snmpv3_priv_key:

```

Optional variables, define these if you need to configure
```yaml
orion_node_snmp_port: string, SNMP port (module default 161)
orion_node_snmp_allow_64: bool, allow 64-bit SNMP counters (module default true)
orion_node_custom_pollers: list, additional custom UnDP pollers
orion_node_interfaces: list, interfaces to monitor
orion_node_volumes: list, volumes to monitor
orion_node_applications: list, APM templates to add to node
orion_node_custom_properties: list, elements are dicts (name, value), custom property names and values to set
orion_node_hardware_health_poller: string, Name of the Hardware Health poller to enable on node
orion_node_ncm_profile_name: string, Name of NCM profile if managing node in NCM
orion_node_enable_asset_inventory: bool, Set to true to enable Asset Inventory polling
orion_node_validate_snmp_required: bool, Set to false to disable forced SNMP validation
orion_node_poll_interval: int, Polling interval for status and response time in seconds (module default 120)
orion_node_stat_collection: int, Stat collection interval in minutes (module default 15)
orion_node_rediscovery_interval: int, Rediscovery interval in minutes (module default 30)
```


Example Playbook
----------------

```yaml

    - name: Add servers to Solarwinds as SNMPv2 nodes
      hosts: servers
      gather_facts: true
      vars:
        solarwinds_server: 127.0.0.1
        solarwinds_username: admin
        solarwinds_password: changeme2345
      roles:
        - role: jeisenbath.solarwinds.orion_node
          orion_node_polling_method: SNMP
          orion_node_snmp_version: 2
          orion_node_ro_community_string: community
          orion_node_discover_interfaces: true

```

License
-------

GPL-3.0-or-later
