#!/usr/bin/python
# -*- coding: utf-8 -*-

# Copyright: (c) 2022, Josh M. Eisenbath <j.m.eisenbath@gmail.com>
# Copyright: (c) 2019, Jarett D. Chaiken <jdc@salientcg.com>
# GNU General Public License v3.0+ (see COPYING or https://www.gnu.org/licenses/gpl-3.0.txt)

from __future__ import absolute_import, division, print_function
__metaclass__ = type

DOCUMENTATION = '''
---
module: orion_node
short_description: Created/Removes/Edits Nodes in Solarwinds Orion NPM
description:
    - "Create or Remove Nodes in Orion NPM."
version_added: "1.0.0"
author:
    - "Jarett D Chaiken (@jdchaiken)"
    - "Josh M. Eisenbath (@jeisenbath)"
options:
    enable_asset_inventory:
        description:
            - Enable polling in Asset Inventory.
        required: false
        type: bool
        default: false
    state:
        description:
            - The desired state of the node.
        required: true
        type: str
        choices:
            - present
            - absent
            - managed
            - unmanaged
            - muted
            - unmuted
    node_id:
        description:
            - Node ID of the node.
            - One of I(ip_address), I(node_id), or I(name) is required.
        required: false
        type: str
    name:
        description:
            - Name of the node.
            - When I(state=present), this field is required.
            - When state is other than present, one of I(ip_address), I(node_id), or I(name) is required.
        required: false
        aliases: [ 'caption' ]
        type: str
    ip_address:
        description:
            - IP Address of the node.
            - One of I(ip_address), I(node_id), or I(name) is required.
        required: false
        type: str
    unmanage_from:
        description:
            - "The date and time (in ISO 8601 UTC format) to begin the unmanage period."
            - If this is in the past, the node will be unmanaged effective immediately.
            - If not provided, module defaults to now.
            - "ex: 2017-02-21T12:00:00Z"
        required: false
        type: str
    unmanage_until:
        description:
            - "The date and time (in ISO 8601 UTC format) to end the unmanage period."
            - You can set this as far in the future as you like.
            - If not provided, module defaults to 24 hours from now.
            - "ex: 2017-02-21T12:00:00Z"
        required: false
        type: str
    polling_method:
        description:
            - Polling method to use.
        choices:
            - External
            - ICMP
            - SNMP
            - WMI
            - Agent
        default: ICMP
        required: false
        type: str
    poll_interval:
        description:
            - The interval in seconds for polling the status and response time for node.
        type: int
        required: false
        default: 120
    ro_community_string:
        description:
            - SNMP Read-Only Community string.
            - Required if I(polling_method=snmp).
        required: false
        type: str
    rw_community_string:
        description:
            - SNMP Read-Write Community string.
        required: false
        type: str
    snmp_version:
        description:
            - SNMPv2c or SNMPv3 for snmp polling.
        choices:
            - "2"
            - "3"
        required: false
        type: str
    snmp_port:
        description:
            - Port that SNMP server listens on.
        required: false
        default: "161"
        type: str
    snmp_allow_64:
        description:
            - Set true if device supports 64-bit counters.
        type: bool
        default: true
        required: false
    snmpv3_credential_set:
        description:
            - Credential set name for SNMPv3 credentials.
            - Optional when SNMP version is 3.
        type: str
        required: false
    snmpv3_username:
        description:
            - Read-Only SNMPv3 username.
            - Required when SNMP version is 3.
        type: str
        required: false
    snmpv3_auth_method:
        description:
            - Authentication method for SNMPv3.
            - Required when SNMP version is 3.
        type: str
        choices:
            - MD5
            - SHA1
            - SHA256
            - SHA512
        required: false
    snmpv3_auth_key:
        description:
            - Authentication passphrase for SNMPv3.
            - Required when SNMP version is 3.
        type: str
        required: false
    snmpv3_auth_key_is_pwd:
        description:
            - SNMPv3 Authentication Password is a key.
            - Confusingly, value of True corresponds to web GUI checkbox being unchecked.
        type: bool
        required: false
    snmpv3_priv_method:
        description:
            - Privacy method for SNMPv3.
        type: str
        choices:
            - DES56
            - AES128
            - AES192
            - AES256
        required: false
    snmpv3_priv_key:
        description:
            - Privacy passphrase for SNMPv3.
        type: str
        required: false
    snmpv3_priv_key_is_pwd:
        description:
            - SNMPv3 Privacy Password is a key.
            - Confusingly, value of True corresponds to web GUI checkbox being unchecked.
        type: bool
        required: false
    stat_collection:
        description:
            - The interval in minutes to gather statistics for node.
        type: int
        required: false
        default: 15
    rediscovery_interval:
        description:
            - The interval in minutes for polling the network to detect any re-indexed interfaces.
        type: int
        required: false
        default: 30
    validate_snmp_required:
        description:
            - Whether SNMP validation must pass before adding the node.
            - If True (default), module will fail if SNMP validation fails.
            - If False, node will be added even if SNMP validation fails (with warning).
            - This mirrors the SolarWinds web interface behavior of allowing nodes with failed SNMP.
        type: bool
        default: true
        required: false
    wmi_credential_set:
        description:
            - 'Credential Name already configured in NPM  Found under "Manage Windows Credentials" section of the Orion website (Settings).'
            - "Note: creation of credentials are not supported at this time."
            - Required if I(polling_method=wmi).
        required: false
        type: str
    polling_engine:
        description:
            - ID of polling engine that NPM will use to poll this device.
            - If not passed, will query for the Polling Engine with least nodes assigned.
            - Not recommended to use I(polling_engine=1), which should be the main app server.
        required: false
        type: str
extends_documentation_fragment:
    - jeisenbath.solarwinds.orion_auth_options
requirements:
    - orionsdk
    - python-dateutil
    - requests
'''

EXAMPLES = '''
---
- name: Add an SNMP node to Orion
  jeisenbath.solarwinds.orion_node:
    hostname: "{{ solarwinds_server }}"
    username: "{{ solarwinds_username }}"
    password: "{{ solarwinds_password }}"
    name: "{{ node_name }}"
    state: present
    ip_address: "{{ node_ip_address }}"
    polling_method: SNMP
    ro_community_string: "{{ snmp_ro_community_string }}"
  delegate_to: localhost

- name: Add an SNMPv3 node even if SNMP validation fails (for testing)
  jeisenbath.solarwinds.orion_node:
    hostname: "{{ solarwinds_server }}"
    username: "{{ solarwinds_username }}"
    password: "{{ solarwinds_password }}"
    name: "{{ node_name }}"
    state: present
    ip_address: "{{ node_ip_address }}"
    polling_method: SNMP
    snmp_version: "3"
    snmpv3_username: "{{ snmpv3_username }}"
    snmpv3_auth_method: "SHA1"
    snmpv3_auth_key: "{{ snmpv3_auth_key }}"
    snmpv3_priv_method: "AES128"
    snmpv3_priv_key: "{{ snmpv3_priv_key }}"
    validate_snmp_required: false
  delegate_to: localhost

- name: Mute node in Solarwinds for 30 minutes
  jeisenbath.solarwinds.orion_node:
    hostname: "{{ solarwinds_host }}"
    username: "{{ solarwinds_username }}"
    password: "{{ solarwinds_password }}"
    state: muted
    ip_address: "{{ ip_address }}"
    unmanage_until: "{{ '%Y-%m-%dT%H:%M:%S' | strftime((now(fmt='%s')|int) + 1800) }}Z"
  delegate_to: localhost
'''

RETURN = r'''
orion_node:
    description: Info about an orion node.
    returned: always
    type: dict
    sample: {
        "caption": "localhost",
        "ipaddress": "127.0.0.1",
        "lastsystemuptimepollutc": "2024-09-25T18:34:20.7630000Z",
        "netobjectid": "N:12345",
        "nodeid": "12345",
        "objectsubtype": "SNMP",
        "status": 1,
        "statusdescription": "Node status is Up.",
        "unmanaged": false,
        "unmanagefrom": "1899-12-30T00:00:00+00:00",
        "unmanageuntil": "1899-12-30T00:00:00+00:00",
        "uri": "swis://host.domain.com/Orion/Orion.Nodes/NodeID=12345",
        "snmp_validation_passed": false,
        "snmp_validation_error": "SNMP validation failed - device did not respond to SNMP poll"
    }
    contains:
        snmp_validation_passed:
            description: Whether SNMP validation passed during node creation.
            returned: when state=present and SNMPv3 is used
            type: bool
        snmp_validation_error:
            description: Error message if SNMP validation failed.
            returned: when state=present, SNMPv3 is used, and validation fails
            type: str
warnings:
    description: List of warning messages about the operation.
    returned: when validate_snmp_required=false and SNMP validation fails
    type: list
    sample: ["WARNING: Node was added but SNMP validation failed - device did not respond to SNMP poll"]
changed:
    description: Whether the module made any changes.
    returned: always
    type: bool
'''

from ansible.module_utils.basic import AnsibleModule
from ansible_collections.jeisenbath.solarwinds.plugins.module_utils.orion import OrionModule, orion_argument_spec
from ansible_collections.jeisenbath.solarwinds.plugins.module_utils.credential import validate_snmp3_credentials
try:
    from datetime import datetime, timedelta
    HAS_DATETIME = True
except ImportError:
    HAS_DATETIME = False
except Exception:
    raise
try:
    import requests
    HAS_REQUESTS = True
    requests.packages.urllib3.disable_warnings()
except ImportError:
    HAS_REQUESTS = False
except Exception:
    raise


def add_credential_set(node, credential_set_name, credential_set_type):
    credential_set_type_valid = ['WMICredential', 'ROSNMPCredentialID', 'RWSNMPCredentialID']
    cred_id_query = __SWIS__.query(
        "SELECT ID FROM Orion.Credential WHERE Name = '{0}'".format(credential_set_name)
    )

    credential_id = cred_id_query['results'][0]['ID']
    if credential_id and credential_set_type in credential_set_type_valid:
        nodesettings = {
            'nodeid': node['nodeid'],
            'SettingName': credential_set_type,
            'SettingValue': str(credential_id),
        }
        __SWIS__.create('Orion.NodeSettings', **nodesettings)


def add_node(module, orion):

    props = {
        'IPAddress': module.params['ip_address'],
        'Caption': module.params['name'],
        'ObjectSubType': module.params['polling_method'].upper(),
        'Community': module.params['ro_community_string'],
        'RWCommunity': module.params['rw_community_string'],
        'SNMPVersion': module.params['snmp_version'],
        'AgentPort': module.params['snmp_port'],
        'Allow64BitCounters': module.params['snmp_allow_64'],
        'External': False,
        'PollInterval': module.params['poll_interval'],
        'StatCollection': module.params['stat_collection'],
        'RediscoveryInterval': module.params['rediscovery_interval'],
    }

    if module.params['polling_engine']:
        props['EngineID'] = module.params['polling_engine']
    else:
        props['EngineID'] = orion.get_least_used_polling_engine()

    if props['ObjectSubType'] == 'EXTERNAL':
        props['ObjectSubType'] = 'ICMP'

    if module.params['polling_method'].upper() == 'EXTERNAL':
        props['External'] = True

    if module.params['snmp_version'] == '3' and props['ObjectSubType'] == 'SNMP':
        # Even when using credential set, node creation fails without providing all three properties
        if module.params['snmpv3_username']:
            props['SNMPV3Username'] = module.params['snmpv3_username']
        if module.params['snmpv3_priv_key']:
            props['SNMPV3PrivKey'] = module.params['snmpv3_priv_key']
        if module.params['snmpv3_auth_key']:
            props['SNMPV3AuthKey'] = module.params['snmpv3_auth_key']

        # Set defaults here instead of at module level, since we only want for snmpv3 nodes
        if module.params['snmpv3_priv_method']:
            props['SNMPV3PrivMethod'] = module.params['snmpv3_priv_method']
        else:
            props['SNMPV3PrivMethod'] = 'AES128'
        if module.params['snmpv3_priv_key_is_pwd']:
            props['SNMPV3PrivKeyIsPwd'] = module.params['snmpv3_priv_key_is_pwd']
        else:
            props['SNMPV3PrivKeyIsPwd'] = True
        if module.params['snmpv3_auth_method']:
            props['SNMPV3AuthMethod'] = module.params['snmpv3_auth_method']
        else:
            props['SNMPV3AuthMethod'] = 'SHA1'
        if module.params['snmpv3_auth_key_is_pwd']:
            props['SNMPV3AuthKeyIsPwd'] = module.params['snmpv3_auth_key_is_pwd']
        else:
            props['SNMPV3AuthKeyIsPwd'] = True

    # Validate credentials
    snmp_validation_passed = True
    snmp_validation_error = None
    if props['ObjectSubType'] == 'SNMP' and props['SNMPVersion'] == '3':
        validateNode = {
            "ipaddress": props['IPAddress'],
            "engineid": props['EngineID']
        }
        validateProperties = {
            "username": props['SNMPV3Username'],
            'priv_method': props['SNMPV3PrivMethod'],
            'priv_key': props['SNMPV3PrivKey'],
            'priv_key_is_pwd': props['SNMPV3PrivKeyIsPwd'],
            'auth_key': props['SNMPV3AuthKey'],
            'auth_method': props['SNMPV3AuthMethod'],
            'auth_key_is_pwd': props['SNMPV3AuthKeyIsPwd'],
        }
        try:
            validated = validate_snmp3_credentials(orion, validateNode, validateProperties, module.params['snmp_port'])
            if not validated:
                snmp_validation_passed = False
                snmp_validation_error = 'SNMP validation failed - device did not respond to SNMP poll'
                if module.params['validate_snmp_required']:
                    module.fail_json(msg='Failed to validate credentials on node.')
        except Exception as OrionException:
            snmp_validation_passed = False
            snmp_validation_error = 'SNMP validation exception: {0}'.format(str(OrionException))
            if module.params['validate_snmp_required']:
                module.fail_json(msg='Failed to validate credentials for node: {0}'.format(str(OrionException)))
    # Add Node
    try:
        __SWIS__.create('Orion.Nodes', **props)
    except Exception as OrionException:
        module.fail_json(msg='Failed to create node: {0}'.format(str(OrionException)))

    # Get node after being created
    node = orion.get_node()

    # If we don't use credential sets, each snmpv3 node will create its own credential set
    # TODO option for read/write sets?
    if props['ObjectSubType'] == 'SNMP' and props['SNMPVersion'] == '3' and module.params['snmpv3_credential_set']:
        add_credential_set(node, module.params['snmpv3_credential_set'], 'ROSNMPCredentialID')

    # If Node is a WMI node, assign credential
    if props['ObjectSubType'] == 'WMI':
        add_credential_set(node, module.params['wmi_credential_set'], 'WMICredential')

    # Add Standard Default Pollers
    icmp_pollers = {
        'N.Status.ICMP.Native': True,
        'N.ResponseTime.ICMP.Native': True,
        'N.IPAddress.ICMP.Generic': True
    }

    snmp_pollers = {
        'N.Status.ICMP.Native': True,
        'N.Status.SNMP.Native': False,
        'N.ResponseTime.ICMP.Native': True,
        'N.ResponseTime.SNMP.Native': False,
        'N.Details.SNMP.Generic': True,
        'N.Uptime.SNMP.Generic': True,
        'N.Routing.SNMP.Ipv4CidrRoutingTable': False,
        'N.Topology_Layer3.SNMP.ipNetToMedia': False,
    }

    if module.params['polling_method'].upper() == 'ICMP':
        pollers_enabled = icmp_pollers
    elif module.params['polling_method'].upper() == 'SNMP':
        pollers_enabled = snmp_pollers
    else:
        pollers_enabled = {}

    for k in pollers_enabled:
        try:
            orion.add_poller('N', str(node['nodeid']), k, pollers_enabled[k])
        except Exception as OrionException:
            module.fail_json(msg='Failed to create pollers on node: {0}'.format(str(OrionException)))

    # Add validation results to node info
    node['snmp_validation_passed'] = snmp_validation_passed
    if not snmp_validation_passed:
        node['snmp_validation_error'] = snmp_validation_error

    # Enable Asset inventory
    if module.params['enable_asset_inventory']:
        orion.manage_asset_inventory([node['nodeid']], module.params['enable_asset_inventory'])

    return node


def remove_node(module, node):
    try:
        __SWIS__.delete(node['uri'])
    except Exception as OrionException:
        module.fail_json(msg='Error removing node: {0}'.format(str(OrionException)))


def remanage_node(module, node):
    try:
        __SWIS__.invoke('Orion.Nodes', 'Remanage', node['netobjectid'])
    except Exception as OrionException:
        module.fail_json(msg='Error remanaging node: {0}'.format(str(OrionException)))


def unmanage_node(module, node):
    now = datetime.now()
    tomorrow = now + timedelta(days=1)
    unmanage_from = module.params['unmanage_from']
    unmanage_until = module.params['unmanage_until']
    if not unmanage_from:
        unmanage_from = now.isoformat()
    if not unmanage_until:
        unmanage_until = tomorrow.isoformat()

    try:
        __SWIS__.invoke(
            'Orion.Nodes',
            'Unmanage',
            node['netobjectid'],
            unmanage_from,
            unmanage_until,
            False  # use Absolute Time
        )
    except Exception as OrionException:
        module.fail_json(msg='Error unmanaging node: {0}'.format(str(OrionException)))


def mute_node(module, node):
    now = datetime.now()
    tomorrow = now + timedelta(days=1)
    unmanage_from = module.params['unmanage_from']
    unmanage_until = module.params['unmanage_until']
    if not unmanage_from:
        unmanage_from = now.isoformat()
    if not unmanage_until:
        unmanage_until = tomorrow.isoformat()

    try:
        __SWIS__.invoke('Orion.AlertSuppression', 'SuppressAlerts', [node['uri']], unmanage_from, unmanage_until)
    except Exception as OrionException:
        module.fail_json(msg='Error muting node: {0}'.format(str(OrionException)))


def unmute_node(module, node):
    try:
        __SWIS__.invoke('Orion.AlertSuppression', 'ResumeAlerts', [node['uri']])
    except Exception as OrionException:
        module.fail_json(msg='Error unmuting node: {0}'.format(str(OrionException)))


def main():
    argument_spec = orion_argument_spec()
    argument_spec.update(
        state=dict(required=True, choices=['present', 'absent', 'managed', 'unmanaged', 'muted', 'unmuted']),
        unmanage_from=dict(required=False, default=None),
        unmanage_until=dict(required=False, default=None),
        polling_method=dict(required=False, default='ICMP', choices=['External', 'ICMP', 'SNMP', 'WMI', 'Agent']),
        ro_community_string=dict(required=False, no_log=True),
        rw_community_string=dict(required=False, no_log=True),
        snmp_version=dict(required=False, default=None, choices=['2', '3']),
        snmpv3_credential_set=dict(required=False, default=None, type='str'),
        snmpv3_username=dict(required=False, type='str'),
        snmpv3_auth_method=dict(required=False, type='str', choices=['MD5', 'SHA1', 'SHA256', 'SHA512']),
        snmpv3_auth_key=dict(required=False, type='str', no_log=True),
        snmpv3_auth_key_is_pwd=dict(required=False, type='bool'),
        snmpv3_priv_method=dict(required=False, type='str', choices=['DES56', 'AES128', 'AES192', 'AES256']),
        snmpv3_priv_key=dict(required=False, type='str', no_log=True),
        snmpv3_priv_key_is_pwd=dict(required=False, type='bool'),
        snmp_port=dict(required=False, default='161'),
        snmp_allow_64=dict(required=False, default=True, type='bool'),
        validate_snmp_required=dict(required=False, default=True, type='bool'),
        wmi_credential_set=dict(required=False, no_log=True),
        polling_engine=dict(required=False),
        enable_asset_inventory=dict(required=False, type='bool', default=False),
        poll_interval=dict(required=False, type='int', default=120),
        stat_collection=dict(required=False, type='int', default=15),
        rediscovery_interval=dict(required=False, type='int', default=30),
    )

    module = AnsibleModule(
        argument_spec,
        supports_check_mode=True,
        required_one_of=[('name', 'node_id', 'ip_address')],
        required_if=[
            ('state', 'present', ('name', 'ip_address', 'polling_method')),
            ('snmp_version', '2', ['ro_community_string']),
            ('snmp_version', '3', ['snmpv3_username', 'snmpv3_auth_key', 'snmpv3_priv_key']),
            ('polling_method', 'SNMP', ['snmp_version']),
            ('polling_method', 'WMI', ['wmi_credential_set']),
        ],
    )

    orion = OrionModule(module)

    global __SWIS__
    __SWIS__ = orion.swis

    node = orion.get_node()

    changed = False
    warnings = []

    if module.params['state'] == 'present':
        if not node:
            if not module.check_mode:
                node = add_node(module, orion)
                # Check if SNMP validation failed but node was still added
                if hasattr(node, 'get') and not node.get('snmp_validation_passed', True):
                    warnings.append("WARNING: Node was added but SNMP validation failed - {0}".format(
                        node.get('snmp_validation_error', 'Unknown SNMP validation error')
                    ))
            changed = True
    elif module.params['state'] == 'absent':
        if node:
            if not module.check_mode:
                remove_node(module, node)
            changed = True
    else:
        if not node:
            module.exit_json(skipped=True, msg='Node not found')
        # SuppressionMode 1 is suppressed, 0 unsuppressed
        suppressed_state = __SWIS__.invoke('Orion.AlertSuppression', 'GetAlertSuppressionState', [node['uri']])[0]
        if module.params['state'] == 'managed':
            if node['unmanaged']:
                if not module.check_mode:
                    remanage_node(module, node)
                changed = True
        elif module.params['state'] == 'unmanaged':
            if not node['unmanaged']:
                if not module.check_mode:
                    unmanage_node(module, node)
                changed = True
        elif module.params['state'] == 'muted':
            if suppressed_state['SuppressionMode'] == 0:
                if not module.check_mode:
                    mute_node(module, node)
                changed = True
        elif module.params['state'] == 'unmuted':
            if suppressed_state['SuppressionMode'] == 1:
                if not module.check_mode:
                    unmute_node(module, node)
                changed = True

    # Prepare exit response
    response = {'changed': changed, 'orion_node': node}
    if warnings:
        response['warnings'] = warnings

    module.exit_json(**response)


if __name__ == "__main__":
    main()
